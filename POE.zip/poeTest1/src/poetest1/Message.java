package poetest1;

import javax.swing.JOptionPane;
import java.util.Random;
import java.util.Scanner;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;

public class Message {
    
    Scanner input = new Scanner(System.in);
    Random rand = new Random();
    //declarations
    ArrayList<String> sentMessages = new ArrayList<>();
    String messageID = "";
    String recipient = "";
    int cell = 0;
    int numMessage = 0;
    int messageCount = 1;
    String messageHash = "";
    String conversation = "";
    String sendMessage = "";
    int totalMessages = 0;

    public void messageManager() {
        JOptionPane.showMessageDialog(null, "==============Welcome to QuickChat.================");
        while (true) {
            selection();
        }
    }

    public void selection() {
        while (true) {
            String sel = JOptionPane.showInputDialog("1. Send Messages \n2. Show recent sent messages \n3. Quit");

            if (sel == null) {

                JOptionPane.showMessageDialog(null, "Please input the selection.");
            }

            int selection;
            try {
                selection = Integer.parseInt(sel);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a number.");
                continue;
            }

            if (selection == 1) {
                JOptionPane.showMessageDialog(null, "You can now send messages");
                sendMessage();
            } else if (selection == 2) {
                JOptionPane.showMessageDialog(null, "Coming Soon");

            } else if (selection == 3) {
            System.exit(0);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid selection. Please choose 1, 2, or 3.");
            }
        }
    }

    //Use substring and loop counters to generate unique Message ID   
    public String generateMessageID() {
        boolean isMoreThan10 = false;
        do {
            Long messageID2 = 1_000_000_000L + (long) (rand.nextDouble() * 9_000_000_000L);
            messageID = String.valueOf(messageID2);
            //call the checkMessageID to check if the random generated number is 10 digits

            isMoreThan10 = checkMessageID();

        } while (!isMoreThan10);

        return this.messageID;
    }

    //validate if number of messageID is 10 digits or not
    public boolean checkMessageID() {

        if (this.messageID.length() != 10) {
            return false;

        } else {
            return true;
        }
    }

    public int checkRecipientCell() {
        while (true) {
            recipient = JOptionPane.showInputDialog(null, "Please enter the recipient cell number (e.g. +27)");
            String trimName = recipient.replace(" ", "".trim());
            if (trimName != null && trimName.contains("+27") && trimName.length() == 12) {
                JOptionPane.showMessageDialog(null, "Cell phone number successfully captured");
                String cell1 = trimName.replace("+27", "0");
                cell = Integer.parseInt(cell1);
                return cell;
            } else {
                JOptionPane.showMessageDialog(null, "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
            }
        }
    }

    //use predifined methods and store Message words in arrays so you can have access to the first and last words
    public String createMessageHash() {
        //convert the messageID to string and select first 2 digits
        String idToStr = this.messageID;
        String first2 = idToStr.substring(0, 2);

        //trim the Message & insert the Message words in an array 
        String[] words = sendMessage.trim().split("\\s+");
        //locate the first and last word in an array
        String firstWord = "";
        String firstWordsToUpper="";
        if (words.length > 0) {
            firstWord = words[0];
             firstWordsToUpper = firstWord.toUpperCase();
        }
        String lastWord = "";
        String lastWordToUpper = "";
        if (words.length > 1) {
            lastWord = words[words.length - 1];
        } else if (words.length == 1) {
            lastWord = words[0];
            lastWordToUpper = lastWord.toUpperCase();
            
        }
        this.messageHash = first2 + ":" + messageCount + ":" + firstWordsToUpper + lastWordToUpper;
        return this.messageHash;
    }
//use a do while loop to loop until the user selects the right option if choice is invalid

    public String SentMessage() {
        boolean isRightOption = false;
        int selection;
        String message = "";
        do {
            String sel = JOptionPane.showInputDialog("Please choose one of the following option \n1.Send \n2. Store \n3.Disregard");
            selection = Integer.parseInt(sel);

            //when user selects send, Message content should be stored in an array with full details
            if (selection == 1) {
                message = "Message successfully sent";
                JOptionPane.showMessageDialog(null, message);
                String cellToStr = String.valueOf(cell);
                String cellToStr2 = cellToStr.substring(0, 9);
                String Details = "\nMessageID : " + this.messageID + "\nMessage Hash : " + this.messageHash;
                String fullMessageInfo = Details + "\nRecipient Number: +27" + cellToStr2 + "\nMessage : " + this.sendMessage + "\nMessage Number" + ": " + messageCount;
                sentMessages.add(fullMessageInfo);

                messageCount++;
                isRightOption = true;

                //user's Message content should be stored using json for later use
            } else if (selection == 2) {
                storeMessageAsJson();
                message = "Message successfully stored";
                JOptionPane.showMessageDialog(null, message);
                isRightOption = true;

            } else if (selection == 3) {
                message = "Message Disregarded";
                JOptionPane.showMessageDialog(null, message);
                isRightOption = true;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid selection");
            }
        } while (!isRightOption);
        return message;
    }

    /*use the number of messages to be sent in a for loop 
    use the if else statement to create a Message with less than 250 character  
    & print out the Message content with JOptionPane together with massage hash, Message id,recipient number 
    then call the returnTotalMethod to print out the total number of messages sent
     */
    public String sendMessage() {
        String numStr = JOptionPane.showInputDialog("Please enter the number of messages you want to send");
        int numOfMessage = Integer.parseInt(numStr);

        for (int i = 0; i < numOfMessage; i++) {
            checkRecipientCell();
            this.sendMessage = JOptionPane.showInputDialog("Please enter a message less than 250 characters ");
            if (this.sendMessage.length() <= 250 && this.sendMessage.length() > 0) {
                generateMessageID();
                createMessageHash();
                String cellToStr = String.valueOf(cell);
                String cellToStr2 = cellToStr.substring(0, 9);
                String Details = "\nMessageID : " + this.messageID + "\nMessage Hash : " + this.messageHash;
                String fullMessageInfo = Details + "\nRecipient Number: +27" + cellToStr2 + "\nMessage : " + this.sendMessage + "\nMessage Number"
                        + ""
                        + ": " + messageCount;

                messageCount = messageCount++;

                JOptionPane.showMessageDialog(null, fullMessageInfo);
                SentMessage();

            } else if (this.sendMessage.length() > 250) {
                //if more than 250 then decrement i and allow to re-enter
                i--;
                JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters");
            } else {
                //if mmessage content empty then decrement i and allow to re-enter       
                JOptionPane.showMessageDialog(null, "Please enter the message don't leave the textbox blank");
                i--;
            }
        }
        returnTotalMessages();
        return this.sendMessage;
    }
//calculate the total messages using the Message counter

    public int returnTotalMessages() {
        totalMessages = 0 + messageCount;
        JOptionPane.showMessageDialog(null, "Total Messages Sent: " + totalMessages);
        return totalMessages;
    }

    public void storeMessageAsJson() {
        try {
            ObjectMapper mapper = new ObjectMapper();

            // Create a simple object to represent the Message
            MessageData messageData = new MessageData(
                    this.recipient,
                    this.cell,
                    this.sendMessage,
                    this.messageID,
                    this.messageHash,
                    this.messageCount
            );

            // Convert to JSON string
            String jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(messageData);

            // Display or store the JSON
            JOptionPane.showMessageDialog(null, "Message stored as JSON:\n" + jsonString);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error storing message as JSON: " + e.getMessage());
        }
    }

    class MessageData {

        public String recipient;
        public int cell;
        public String messageContent;
        public String messageID;
        public String messageHash;
        public int messageCount;

        public MessageData(String recipient, int cell, String messageContent, String messageID, String messageHash, int messageCount) {
            this.recipient = recipient;
            this.cell = cell;
            this.messageContent = messageContent;
            this.messageID = messageID;
            this.messageHash = messageHash;
            this.messageCount = messageCount;
        }
    }

    public String printMessages() {
        for (String msg : sentMessages) {
            JOptionPane.showMessageDialog(null, msg);
            conversation = msg;
        }

        return conversation;
    }
}
