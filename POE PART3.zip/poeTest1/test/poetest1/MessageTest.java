
package poetest1;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


public class MessageTest {

    private Message msg;

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
        msg = new Message();
    }

    @AfterEach
    public void tearDown() {
    }
    //(referenced from chatgbt
    @Test
    @DisplayName("generateMessageID() returns a 10‑digit numeric string")
    void testGenerateMessageIDLength() {
        String id = msg.generateMessageID();
        assertAll(
                () -> assertEquals(10, id.length(), "ID must be 10 digits"),
                () -> assertTrue(id.matches("\\d{10}"), "ID must be numeric")
        );
    }

    @Test
    @DisplayName("checkMessageID() true for 10 digits, false otherwise")
    void testCheckMessageID() {
        msg.messageID = "1234567890";
        assertTrue(msg.checkMessageID());

        msg.messageID = "1234";
        assertFalse(msg.checkMessageID());
    }

    @Test
    @DisplayName("checkMessageID() rejects 9‑ and 11‑digit IDs (edge cases)")
    void testInvalidMessageIDLengths() {
        msg.messageID = "123456789";
        assertFalse(msg.checkMessageID());

        msg.messageID = "12345678901";
        assertFalse(msg.checkMessageID());
    }

    @Test
    @DisplayName("createMessageHash() builds the expected pattern")
    void testCreateMessageHash() {
        msg.messageID = "9876543210";
        msg.messageCount = 3;
        msg.sendMessage = "Hello world";

        String hash = msg.createMessageHash();
        assertEquals("98:3:HELLOWORLD", hash);
    }

    @Test
    @DisplayName("returnTotalMessages() equals messageCount value")
    void testReturnTotalMessages() {
        msg.messageCount = 7;
        int total = msg.returnTotalMessages();
        assertEquals(7, total);
    }
}
