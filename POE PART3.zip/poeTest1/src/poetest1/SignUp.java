package poetest1;

import javax.swing.JOptionPane;

class SignUp {

    public static int signUp(String[] usernames, String[] passwords, int userCount, int[] phoneNumbers) {

        JOptionPane.showMessageDialog(null, "=====================Sign Up===================");
        //loop within methods in order not to loop whole sign up code
        String username = checkUsername(usernames, userCount);
        String password = checkPassword();
        int phoneNumber = checkCell();

        usernames[userCount] = username;
        passwords[userCount] = password;
        phoneNumbers[userCount] = phoneNumber;
        userCount++;
        JOptionPane.showMessageDialog(null, "User " + userCount + " details registered!\n======================================================");

        return userCount;
    }

    /*make use of a method to loop and display message if conditions has not met
         pass the scanner to the method
         declare strings
         use a while loop to loop until the condition is met
         state which conditions should be met for the username to be captured
         use the if else statement to display the message*/
    public static String checkUsername(String[] usernames, int userCount) {
        String username;
        while (true) {
            username = JOptionPane.showInputDialog("Please enter username less than 5 characters (must include '_')");

            boolean exists = false;
            for (int i = 0; i < userCount; i++) {
                if (usernames[i].equals(username)) {
                    exists = true;
                    break;
                }
            }

            if (exists) {
                JOptionPane.showMessageDialog(null, "Username already exists. Please try a different username.");
            } else if (username.length() <= 5 && username.contains("_")) {
                JOptionPane.showMessageDialog(null, "Username successfully captured");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Username is not correctly formatted. Ensure that it contains an underscore and is no more than five characters in length.");
            }
        }
        return username;
    }

    //make use of a method in order to loop and display message if conditions has not met
    //declare strings
    //use a while loop to loop until the condition is met
    //call another method(meetsCondition) within this method to display messages if conditions were met or not
    //use the if else statement to display the message
    public static String checkPassword() {
        String password;
        while (true) {
            password = JOptionPane.showInputDialog("Please enter at least 8 character password");

            if (meetsCondition(password)) {
                JOptionPane.showMessageDialog(null, "Password successfully captured");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character");
            }
        }
        return password;
    }

    //make use of boolean to check the characters in password meets all the required contions
    public static boolean meetsCondition(String password) {
        if (password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasDigit = false;
        boolean hasSpecialCharacter = false;

        for (int p = 0; p < password.length(); p++) {
            char c = password.charAt(p);//referred to chatgpt...the statement is about getting each charcater in the password one by one
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            }
            if (Character.isDigit(c)) {
                hasDigit = true;
            }
            if (!Character.isLetterOrDigit(c)) {
                hasSpecialCharacter = true;
            }
        }
        return hasCapital && hasDigit && hasSpecialCharacter;
    }
    //referred to chatgpt for the for loop

    public static int checkCell() {
        while (true) {
            String cell = JOptionPane.showInputDialog(null, "Please enter the recipient cell number (e.g. +27)");
            String trimName = cell.replace(" ", "".trim());
            if (trimName != null && trimName.contains("+27") && trimName.length() == 12) {
                JOptionPane.showMessageDialog(null, "Cell phone number successfully captured");
                String cell1 = trimName.replace("+27", "0");
                int phoneNumber = Integer.parseInt(cell1);
                return phoneNumber;
            } else {
                JOptionPane.showMessageDialog(null, "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
            }
        }
    }
}
