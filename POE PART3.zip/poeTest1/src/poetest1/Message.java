package poetest1;

import javax.swing.JOptionPane;
import java.util.Random;
import java.util.Scanner;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;

public class Message {

    Scanner input = new Scanner(System.in);
    Random rand = new Random();
    //declarations
    ArrayList<String> sentMessages = new ArrayList<>();
    ArrayList<String> messageIDs = new ArrayList<>();
    ArrayList<String> recipientNumbers = new ArrayList<>();

    String messageID = "";
    String recipient = "";
    int cell = 0;
    int choice = 0;
    int numMessage = 0;
    int messageCount = 1;
    String messageHash = "";
    String conversation = "";
    String sendMessage = "";
    int totalMessages = 0;

    public void messageManager() {
        JOptionPane.showMessageDialog(null, "==============Welcome to QuickChat.================");
        while (true) {
            selection();
        }
    }

    public void selection() {
        while (true) {
            String sel = JOptionPane.showInputDialog("1. Send Messages \n2. Show recent sent messages \n3.Search Message\n4. Quit");

            if (sel == null) {

                JOptionPane.showMessageDialog(null, "Please input the selection.");
            }

            int selection;
            try {
                selection = Integer.parseInt(sel);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a number.");
                continue;
            }

            if (selection == 1) {
                JOptionPane.showMessageDialog(null, "You can now send messages");
                sendMessage();
            } else if (selection == 2) {
              //show all the messages sent
                showAllSentMessages();

            } else if (selection == 3) {
                searchMessages();

            } else if (selection == 4) {
                System.exit(0);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid selection. Please choose 1, 2, or 3.");
            }
        }
    }

    //Use substring and loop counters to generate unique Message ID   
    public String generateMessageID() {
        boolean isMoreThan10 = false;
        do {
            Long messageID2 = 1_000_000_000L + (long) (rand.nextDouble() * 9_000_000_000L);
            messageID = String.valueOf(messageID2);
            //call the checkMessageID to check if the random generated number is 10 digits

            isMoreThan10 = checkMessageID();

        } while (!isMoreThan10);

        return this.messageID;
    }

    //validate if number of messageID is 10 digits or not
    public boolean checkMessageID() {

        if (this.messageID.length() != 10) {
            return false;

        } else {
            return true;
        }
    }

    public int checkRecipientCell() {
        while (true) {
            recipient = JOptionPane.showInputDialog(null, "Please enter the recipient cell number (e.g. +27)");
            this.recipient.trim();
            String trimName = recipient.replace(" ", "".trim());
            if (trimName != null && trimName.contains("+27") && trimName.length() == 12) {
                JOptionPane.showMessageDialog(null, "Cell phone number successfully captured");
                String cell1 = trimName.replace("+27", "0");
                cell = Integer.parseInt(cell1);
                return cell;
            } else {
                JOptionPane.showMessageDialog(null, "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
            }
        }
    }

    //use predifined methods and store Message words in arrays so you can have access to the first and last words
    public String createMessageHash() {
        //convert the messageID to string and select first 2 digits
        String idToStr = this.messageID;
        String first2 = idToStr.substring(0, 2);

        //trim the Message & insert the Message words in an array 
        String[] words = sendMessage.trim().split("\\s+");
        //locate the first and last word in an array
        String firstWord = "";
        String firstWordsToUpper = "";
        if (words.length > 0) {
            firstWord = words[0];
            firstWordsToUpper = firstWord.toUpperCase();
        }
        String lastWord = "";
        String lastWordToUpper = "";
        if (words.length > 1) {
            lastWord = words[words.length - 1];
        } else if (words.length == 1) {
            lastWord = words[0];
            lastWordToUpper = lastWord.toUpperCase();

        }
        this.messageHash = first2 + ":" + messageCount + ":" + firstWordsToUpper + lastWordToUpper;
        return this.messageHash;
    }
//use a do while loop to loop until the user selects the right option if choice is invalid

    public String SentMessage() {
        boolean isRightOption = false;
        int selection;
        String message = "";
        do {
            String sel = JOptionPane.showInputDialog("Please choose one of the following option \n1.Send \n2. Store \n3.Disregard");
            selection = Integer.parseInt(sel);

            //when user selects send, Message content should be stored in an array with full details
            if (selection == 1) {
                message = "Message successfully sent";
                JOptionPane.showMessageDialog(null, message);
                String cellToStr = String.valueOf(cell);
                String cellToStr2 = cellToStr.substring(0, 9);
                String Details = "\nMessageID : " + this.messageID + "\nMessage Hash : " + this.messageHash;
                String fullMessageInfo = Details + "\nRecipient Number: +27" + cellToStr2 + "\nMessage : " + this.sendMessage + "\nMessage Number" + ": " + messageCount;
                sentMessages.add(fullMessageInfo);
                messageIDs.add(this.messageID);
                recipientNumbers.add(this.recipient);
                messageCount++;
                isRightOption = true;

                //user's Message content should be stored using json for later use
            } else if (selection == 2) {
                storeMessageAsJson();
                message = "Message successfully stored";
                messageIDs.add(this.messageID);
                recipientNumbers.add(this.recipient);
                JOptionPane.showMessageDialog(null, message);
                isRightOption = true;

            } else if (selection == 3) {
                message = "Message Disregarded";
                JOptionPane.showMessageDialog(null, message);
                isRightOption = true;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid selection");
            }
        } while (!isRightOption);
        return message;
    }

    /*use the number of messages to be sent in a for loop 
    use the if else statement to create a Message with less than 250 character  
    & print out the Message content with JOptionPane together with massage hash, Message id,recipient number 
    then call the returnTotalMethod to print out the total number of messages sent
     */
    public String sendMessage() {
        String numStr = JOptionPane.showInputDialog("Please enter the number of messages you want to send");
        int numOfMessage = Integer.parseInt(numStr);

        for (int i = 0; i < numOfMessage; i++) {
            checkRecipientCell();
            this.sendMessage = JOptionPane.showInputDialog("Please enter a message less than 250 characters ");
            if (this.sendMessage.length() <= 250 && this.sendMessage.length() > 0) {
                generateMessageID();
                createMessageHash();
                String cellToStr = String.valueOf(cell);
                String cellToStr2 = cellToStr.substring(0, 9);
                String Details = "\nMessageID : " + this.messageID + "\nMessage Hash : " + this.messageHash;
                String fullMessageInfo = Details + "\nRecipient Number: +27" + cellToStr2 + "\nMessage : " + this.sendMessage + "\nMessage Number"
                        + ""
                        + ": " + messageCount;

                messageCount = messageCount++;

                JOptionPane.showMessageDialog(null, fullMessageInfo);
                SentMessage();

            } else if (this.sendMessage.length() > 250) {
                //if more than 250 then decrement i and allow to re-enter
                i--;
                JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters");
            } else {
                //if mmessage content empty then decrement i and allow to re-enter       
                JOptionPane.showMessageDialog(null, "Please enter the message don't leave the textbox blank");
                i--;
            }
        }
        returnTotalMessages();
        return this.sendMessage;
    }
//calculate the total messages using the Message counter

    public int returnTotalMessages() {
        totalMessages = 0 + messageCount;
        JOptionPane.showMessageDialog(null, "Total Messages Sent: " + totalMessages);
        return totalMessages;
    }

    public void storeMessageAsJson() {
        try {
            ObjectMapper mapper = new ObjectMapper();

            // Create a simple object to represent the Message
            MessageData messageData = new MessageData(
                    this.recipient,
                    this.cell,
                    this.sendMessage,
                    this.messageID,
                    this.messageHash,
                    this.messageCount
            );

            // Convert to JSON string
            String jsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(messageData);

            // Display or store the JSON
            JOptionPane.showMessageDialog(null, "Message stored as JSON:\n" + jsonString);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error storing message as JSON: " + e.getMessage());
        }
    }

    class MessageData {

        public String recipient;
        public int cell;
        public String messageContent;
        public String messageID;
        public String messageHash;
        public int messageCount;

        public MessageData(String recipient, int cell, String messageContent, String messageID, String messageHash, int messageCount) {
            this.recipient = recipient;
            this.cell = cell;
            this.messageContent = messageContent;
            this.messageID = messageID;
            this.messageHash = messageHash;
            this.messageCount = messageCount;
        }
    }

    public String printMessages() {
        for (String msg : sentMessages) {
            JOptionPane.showMessageDialog(null, msg);
            conversation = msg;
        }

        return conversation;
    }

    public void searchMessages() {
        String sel = JOptionPane.showInputDialog(
                "Please enter the type of search you want to use\n"
                + "1. Longest Message\n"
                + "2. MessageID Search\n"
                + "3. Recipient Search\n"
                + "4. Delete Message\n");

        if (sel == null || sel.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Search cancelled.");
            return;
        }

        try {
            choice = Integer.parseInt(sel);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid selection – please enter a number from 1 to 5.");
            return;
        }

        switch (choice) {
            case 1:
                //Display the longest message
                showLongestMessage();
                break;
            case 2:
                //linear search using messageID
                searchMessageByID();
                break;
            case 3:
                //linear search using recipient number
                searchMessagesByRecipient();
                break;
            case 4:
                //delete message using message hash
                deleteMessageByHash();
                break;
            default:
                JOptionPane.showMessageDialog(null, "Invalid selection – please enter 1 to 5.");
        }

    }

    /**
     * Prompt the user for a 10‑digit MessageID and performs a linear search
     * through messageIDs. If found, it shows the corresponding full message
     * from sentMessages.
     */
    public void searchMessageByID() {

        String target = JOptionPane.showInputDialog(
                null,
                "Enter the 10‑digit MessageID you want to find:");
        if (target == null || target.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Search cancelled.");
            return;
        }

        int index = -1;

        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(target)) {
                index = i;
                break;
            }
        }

        if (index != -1) {
            String fullRecord = sentMessages.get(index);
            JOptionPane.showMessageDialog(null,
                    "Message found:\n\n" + fullRecord);
        } else {
            JOptionPane.showMessageDialog(null,
                    "No message with ID " + target + " was found.");
        }
    }
// Linear search that prints every stored message /sent message to the recipient if recipients entered digits are verified 

    public void searchMessagesByRecipient() {

        String target = JOptionPane.showInputDialog(
                null,
                "Enter the recipient number to display all messages (e.g. +27831234567):");
        if (target == null || target.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Search cancelled.");
            return;
        }

        StringBuilder results = new StringBuilder();
        for (int i = 0; i < recipientNumbers.size(); i++) {
            if (recipientNumbers.get(i).equals(target)) {
                results.append(sentMessages.get(i)).append("\n\n");
            }
        }

        if (results.length() > 0) {
            JOptionPane.showMessageDialog(null,
                    "Messages sent to " + target + ":\n\n" + results.toString());
        } else {
            JOptionPane.showMessageDialog(null,
                    "No messages found for " + target + ".");
        }
    }
//showing all sent messages

    public void showAllSentMessages() {

        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "No messages have been sent yet.");
            return;
        }
        StringBuilder sb = new StringBuilder("=== SENT MESSAGES ===\n\n");
        for (String msg : sentMessages) {
            sb.append(msg)
                    .append("\n--------------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
//delete massage using message hash

    public void deleteMessageByHash() {

        String targetHash = JOptionPane.showInputDialog(
                null,
                "Enter the exact Message Hash you want to delete:");
        if (targetHash == null || targetHash.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Delete cancelled.");
            return;
        }

        int index = -1;

        for (int i = 0; i < sentMessages.size(); i++) {

            if (sentMessages.get(i).contains("Message Hash : " + targetHash)) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            String removedRecord = sentMessages.get(index);

            sentMessages.remove(index);
            messageIDs.remove(index);
            recipientNumbers.remove(index);

            JOptionPane.showMessageDialog(null,
                    "Message deleted:\n\n" + removedRecord);
        } else {
            JOptionPane.showMessageDialog(null,
                    "No message with hash \"" + targetHash + "\" was found.");
        }
    }
//search for the longest message

    public void showLongestMessage() {

        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "No messages have been sent yet.");
            return;
        }

        String longestRecord = "";
        int longestLength = -1;

        for (String record : sentMessages) {

            int start = record.indexOf("\nMessage : ");
            if (start == -1) {
                continue;
            }
            start += "\nMessage : ".length();

            int end = record.indexOf("\nMessage Number", start);
            if (end == -1) {
                end = record.length();
            }

            String body = record.substring(start, end).trim();

            if (body.length() > longestLength) {
                longestLength = body.length();
                longestRecord = record;
            }
        }

        JOptionPane.showMessageDialog(null,
                "\n\n"
                + longestRecord);
    }

}
