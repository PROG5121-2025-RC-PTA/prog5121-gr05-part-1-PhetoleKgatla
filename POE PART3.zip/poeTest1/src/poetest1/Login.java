
        package poetest1;

import javax.swing.JOptionPane;

class Login {

    public static void loginUser(String[] usernames, String[] passwords, int userCount) {
        Message continuation = new Message();
        //===========================Login===================
        JOptionPane.showMessageDialog(null, "===========================Login===================");
        boolean verified = false;

        do {
            //Please enter your username
            String name = JOptionPane.showInputDialog(null, "Please enter your username");
            //Please enter your password
            String pass = JOptionPane.showInputDialog(null, "Please enter your password");

            for (int i = 0; i < userCount; i++) {
                if (name != null && pass != null && name.equals(usernames[i]) && pass.equals(passwords[i])) {
                    verified = true;
                    JOptionPane.showMessageDialog(null, usernames[i] + " it is great to see you");
                    continuation.messageManager(); //call Message system if login is successful
                    break;
                }
            }

            if (!verified) {
                JOptionPane.showMessageDialog(null, "Username or Password incorrect. Please try again!");
            }

        } while (!verified);
    }
}
