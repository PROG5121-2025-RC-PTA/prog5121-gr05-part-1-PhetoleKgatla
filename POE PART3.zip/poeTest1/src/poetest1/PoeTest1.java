package poetest1;

import javax.swing.JOptionPane;

public class PoeTest1 {

    public static void main(String[] args) {

        //insert the scanner
        // Scanner input = new Scanner(System.in); // no longer needed for JOptionPane
        //call Signup class in main class
        SignUp signUp = new SignUp();
        //call Login class in main class
        Login userLogin = new Login();
        Message continuation = new Message();

        //declaring the data type of decision  im gonna use
        int selection;
        //assigning userCount to zero because in order to increment without being overwritten
        int userCount = 0;
        //using array to store username and passwords 
        //declare the length of passwords and username an array should hold
        String[] usernames = new String[5];
        String[] passwords = new String[5];
        int[] phoneNumbers = new int[5];
        //referred to chatgpt..."move the array to the main so that every method can access them"

        //create a decision menu for users, so that existing users can be able to access the login site
        //using a for loop to loop the menu until certain criteria is met
        //make use of the else if & if statements as your decision tool
        for (int i = 0; i < 20; i++) {
            String inputStr = JOptionPane.showInputDialog("1. Sign up \n2. Login \n3.Quit");
            try {
                selection = Integer.parseInt(inputStr); // nextInt without nextLine causes buffer to the upcoming prompts, tested referred to chatgpt "
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter 1 or 2 or 3.");
                continue;
            }

            //make use of else if statement for the user select the option he/she want to execute(menu like option)
            if (selection == 1) {
                if (userCount < usernames.length) {
                    userCount = signUp.signUp(usernames, passwords, userCount, phoneNumbers);
                } else {
                    JOptionPane.showMessageDialog(null, "User limit reached");
                    userLogin.loginUser(usernames, passwords, userCount);
                    break;
                }
                //if option 1, the sign up code will executed

            } else if (selection == 2) {
                userLogin.loginUser(usernames, passwords, userCount);
                //if user select option2, the login code will be executed
            } else if (selection == 3) {
                System.exit(0);
            } else {
                JOptionPane.showMessageDialog(null, "You chose the wrong option");
                //referred to chatgpt
            }
        }
    }
}
